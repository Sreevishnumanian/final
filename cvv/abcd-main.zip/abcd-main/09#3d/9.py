import numpy as np 
import cv2
left_image = cv2.imread('left.png', cv2.IMREAD_GRAYSCALE) 
height, width = left_image.shape 
right_image = cv2.imread('right.png', cv2.IMREAD_GRAYSCALE) 
right_image = cv2.resize(right_image, (width, height)) 
stereo = cv2.StereoBM.create(numDisparities=16, blockSize=15) 
disparity = stereo.compute(left_image,right_image) 

cv2.imshow("Image",disparity)