import cv2
import numpy as np

image = cv2.imread("image.jpg")
image1 = cv2.imread("image.jpg")

# cv2.imshow("Image",image)


grayImage = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
hsvImage = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)

# cv2.imshow("Gray Image",grayImage)
# cv2.imshow("HSV Image",hsvImage)

histImage = cv2.equalizeHist(grayImage)

# cv2.imshow("Hist Image",hsvImage)

kernel = np.array([[0,1,0],[1,4,1],[0,1,0]])

imageCNN = cv2.filter2D(image,-1,kernel)

# cv2.imshow("CNN Image",imageCNN)


imageBlur = cv2.GaussianBlur(image,(5,5),0)

# cv2.imshow("Blur Image",imageBlur)

sobel_x = cv2.Sobel(grayImage,cv2.CV_64F,1,0,ksize=3)
sobel_y = cv2.Sobel(grayImage,cv2.CV_64F,0,1,ksize=3)


gradientImage = cv2.magnitude(sobel_x,sobel_y)
# cv2.imshow("Gradient Image",gradientImage)


edgeimage = cv2.Canny(grayImage,threshold1=100,threshold2=200)
cv2.imshow("Egde Image",edgeimage)
