import cv2 
import numpy as np
image = cv2.imread("image.jpg")
image2 = cv2.imread("image.jpg")


# cv2.imshow("Load Image",image)
# cv2.imshow("Crop Image",image[30:500,30:500])

resizeimage = cv2.resize(image,(300,300))
# cv2.imshow("Resize Image",resizeimage)



grayImage = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

# cv2.imshow("Gray Image",grayImage)

_,thresholdImage = cv2.threshold(grayImage,127,255,cv2.THRESH_BINARY)


# cv2.imshow("Thresh Image",thresholdImage)


contour,_ = cv2.findContours(thresholdImage,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

cv2.drawContours(image,contour,-1,(0,255,0),2)

contourImage = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)

# cv2.imshow("Contour Image",contourImage)


params = cv2.SimpleBlobDetector_Params()

detector = cv2.SimpleBlobDetector_create(params)

key = detector.detect(image2)

blob = cv2.drawKeypoints(image2,key,np.array([]),(0,0,255),cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

blobImage = cv2.cvtColor(blob,cv2.COLOR_BGR2RGB)

cv2.imshow("Blob Image",blob)
