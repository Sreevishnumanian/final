import cv2 
import mediapipe as mp 
mp_drawing = mp.solutions.drawing_utils 
mp_pose = mp.solutions.pose 
pose = mp_pose.Pose( 
min_detection_confidence=0.5, 
min_tracking_confidence=0.5) 
image = cv2.imread('pose.jpg') 
RGB = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) 
results = pose.process(RGB) 
image_with_landmarks = RGB.copy() 
mp_drawing.draw_landmarks( 
image_with_landmarks, results.pose_landmarks, mp_pose.POSE_CONNECTIONS) 
cv2.imshow("Pose" ,cv2.cvtColor(image_with_landmarks, cv2.COLOR_RGB2BGR)) 