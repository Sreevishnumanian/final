import cv2
import numpy as np

num_rows = 6
num_cols = 9
input_image_path = 'images.png'

image = cv2.imread(input_image_path)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

grid_size = 1.0 
objp = np.zeros((num_rows * num_cols, 3), np.float32)
objp[:, :2] = np.mgrid[0:num_cols, 0:num_rows].T.reshape(-1, 2) * grid_size

ret, corners = cv2.findCirclesGrid(
    gray, (num_cols, num_rows), None, cv2.CALIB_CB_SYMMETRIC_GRID
)

if ret:
    obj_points = [objp]
    img_points = [corners]

    ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(obj_points, img_points, gray.shape[::-1], None, None)

    calibration_data = {
        "camera_matrix": mtx,
        "distortion_coefficients": dist,
    }
    np.save("camera_calibration.npy", calibration_data)

    print("Camera Matrix:")
    print(mtx)
    print("\nDistortion Coefficients:")
    print(dist)

    for corner in corners:
        cv2.circle(image, (int(corner[0][0]), int(corner[0][1])), 3, (0, 0, 255), -1) 
    cv2.imshow("Calibration Image", image)
    
else:
    print("Corners not found. Calibration failed.")
