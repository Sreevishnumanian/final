import cv2

image = cv2.imread("image.jpg")

cv2.imshow("Image",image)


imageLine = image.copy()

pt1 = (50,50)
pt2 = (100,100)
color = (255, 255, 0)
thickness=4

cv2.line(imageLine,pt1,pt2,color,thickness)
cv2.imshow("Line Image",imageLine)


imageCircle = image.copy()
center = (150,150)
radius = 50

cv2.circle(imageCircle,center,radius,color,thickness)
cv2.imshow("Circle Image",imageCircle)


imageRect = image.copy()

startPoint = (0,0)
endPoint = (500,200)



cv2.rectangle(imageRect,startPoint,endPoint,color,thickness)
cv2.imshow("Rectangle Image",imageRect)


imageElipse = image.copy()

centerel = (500,500)
axis = (100,50)

cv2.ellipse(imageElipse,centerel,axis,0,0,360,color,thickness)

cv2.imshow("Elipse Image",imageElipse)
