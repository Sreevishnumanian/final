import cv2
import numpy as np
image = cv2.imread("image.jpg")


# cv2.imshow("Image",image)

grayImage = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

f_trans = np.fft.fft2(grayImage)
f_shift = np.fft.fftshift(f_trans)

magnitude_spectrum = 20 * np.log(np.abs(f_shift))
# cv2.imshow("F Image",magnitude_spectrum)

edgeImage = cv2.Canny(grayImage,50,100)
# cv2.imshow("Edge Image",edgeImage)

orb = cv2.ORB_create()
keypoints, descriptors = orb.detectAndCompute(grayImage, None)
keypoint_image = cv2.drawKeypoints(image, keypoints, None)
# cv2.imshow("ORB",keypoint_image)


bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
matches = bf.match(descriptors, descriptors)
matches = sorted(matches, key=lambda x: x.distance)

matched_image = cv2.drawMatches(image, keypoints, image, keypoints, matches[:10], None,
                                 flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

cv2.imshow("Matched image",matched_image)


#clone copy()