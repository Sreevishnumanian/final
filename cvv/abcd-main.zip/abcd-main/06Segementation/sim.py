import cv2
import numpy as np
image = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)

threshold_value = 128  # You can adjust this threshold value as needed
_, segmented_image = cv2.threshold(image, threshold_value, 255, cv2.THRESH_BINARY)

cv2.imshow('Original Image', image)
cv2.imshow('Segmented Image', segmented_image)



mask = np.zeros(image.shape[:2], np.uint8)

rect = (0, 0, 400, 300)  
bgdModel = np.zeros((1, 65), np.float64)
fgdModel = np.zeros((1, 65), np.float64)

cv2.grabCut(image, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)

mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
segmented_image = image * mask2[:, :, np.newaxis]

cv2.imshow('Segmented Image', segmented_image)

graphcut_mask = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')

graphcut_segmented = image * graphcut_mask[:, :, np.newaxis]
cv2.imshow('Grapg Image', graphcut_segmented)
