import numpy as np
import cv2

image_path = 'image.jpg'
image = cv2.imread(image_path, cv2.IMREAD_COLOR)
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

mask = np.zeros(image.shape[:2], np.uint8)

rect = (25, 25, image.shape[1] - 20, image.shape[0] - 20)

bgdModel = np.zeros((1, 65), np.float64)
fgdModel = np.zeros((1, 65), np.float64)

cv2.grabCut(image, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)

graphcut_mask = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')

graphcut_segmented = image * graphcut_mask[:, :, np.newaxis]

mask.fill(0)
mask[graphcut_mask == 1] = cv2.GC_PR_FGD  
cv2.grabCut(image, mask, None, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_MASK)

grabcut_mask = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')

grabcut_segmented = image * grabcut_mask[:, :, np.newaxis]

cv2.imshow("GraphCut", graphcut_segmented)
cv2.imshow("GrabCut", grabcut_segmented)

