import cv2
import numpy as np


your_array = np.array([[100, 150, 200],
                      [50, 75, 100],
                      [25, 50, 75]], dtype=np.uint8)

gray_image = cv2.cvtColor(your_array, cv2.COLOR_GRAY2BGR)

cv2.imwrite('grayscale_image.jpg', gray_image)
