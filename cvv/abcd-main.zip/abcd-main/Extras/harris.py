import cv2
import numpy as np

image = cv2.imread('moon.jpg')
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

dst = cv2.cornerHarris(gray_image, 2, 3, 0.04)

dst = cv2.dilate(dst, None)

threshold = 0.01 * dst.max()

result = image.copy()

result[dst > threshold] = [0, 0, 255]

cv2.imshow('Harris Corners Detected', result)
cv2.waitKey(0)
cv2.destroyAllWindows()