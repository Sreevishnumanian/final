import cv2
import numpy as np

image1 = cv2.imread('moon.jpg')
image2 = cv2.imread('pose.jpg')
image2 = cv2.resize(image2, (image1.shape[1], image1.shape[0]))

addition_result = cv2.add(image1, image2)
subtraction_result = cv2.subtract(image1, image2)
multiplication_result = cv2.multiply(image1, image2)
epsilon = 1e-5
division_result = cv2.divide(image1, image2 + epsilon, dtype=cv2.CV_32F)
difference_result = cv2.absdiff(image1, image2)

cv2.imshow('Addition Result', addition_result)
cv2.imshow('Subtraction Result', subtraction_result)
cv2.imshow('Multiplication Result', multiplication_result)
cv2.imshow('Division Result', division_result)
cv2.imshow('Difference Result', difference_result)

cv2.waitKey(0)
cv2.destroyAllWindows()
