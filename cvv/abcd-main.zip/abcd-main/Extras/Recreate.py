import cv2
import numpy as np
width = int(input("Enter the width of the image: "))
height = int(input("Enter the height of the image: "))

blank_image = 255 * np.ones((height, width, 3), dtype=np.uint8) 

cv2.imshow('Blank Image', blank_image)
cv2.imwrite('blank_image.jpg', blank_image)

cv2.waitKey(0)
cv2.destroyAllWindows()
