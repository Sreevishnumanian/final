import cv2
import numpy as np

gray_image = cv2.imread('pose.jpg', cv2.IMREAD_GRAYSCALE)

if gray_image is not None:
    gray_values = gray_image.tolist()

    gray_array = np.array(gray_values)

    print("Grayscale image converted to array:")
    print(gray_array)
else:
    print("Error: Could not load the image.")