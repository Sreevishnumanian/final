import numpy as np
import cv2
kalman = cv2.KalmanFilter(4, 2) 
kalman.transitionMatrix = np.array([[1, 0, 1, 0],
                                    [0, 1, 0, 1],
                                    [0, 0, 1, 0],
                                    [0, 0, 0, 1]], dtype=np.float32)

kalman.measurementMatrix = np.array([[1, 0, 0, 0],
                                    [0, 1, 0, 0]], dtype=np.float32)

kalman.statePost = np.array([[300], [200], [0], [0]], dtype=np.float32)

kalman.processNoiseCov = 1e-4 * np.eye(4)

kalman.measurementNoiseCov = 10 * np.eye(2)

kalman.errorCovPost = np.eye(4)

cap = cv2.VideoCapture('input_video.mp4')  
while True:
    ret, frame = cap.read()
    if not ret:
        break

    prediction = kalman.predict()

    predicted_x, predicted_y = prediction[0], prediction[1]

    cv2.circle(frame, (int(predicted_x), int(predicted_y)), 5, (0, 255, 0), -1)

    measurement = np.array([[predicted_x], [predicted_y]], dtype=np.float32)

    estimated = kalman.correct(measurement)

    corrected_x, corrected_y = estimated[0], estimated[1]

    cv2.circle(frame, (int(corrected_x), int(corrected_y)), 5, (0, 0, 255), -1)

    cv2.imshow('Frame', frame)

    if cv2.waitKey(30) == 27:
        break

cv2.destroyAllWindows()
cap.release()