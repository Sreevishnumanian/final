import cv2
import numpy as np

image = cv2.imread('pose.jpg')

scaled_image = cv2.resize(image, None, fx=2, fy=2, interpolation=cv2.INTER_LINEAR)

gamma = 2.0
gamma_corrected_image = np.power(image / 255.0, gamma)
gamma_corrected_image = (gamma_corrected_image * 255).astype(np.uint8)

clipped_image = np.clip(image, 100, 200)

min_pixel_value = 50
max_pixel_value = 150
windowed_image = cv2.convertScaleAbs(image, alpha=255.0 / (max_pixel_value - min_pixel_value), beta=-min_pixel_value * 255.0 / (max_pixel_value - min_pixel_value))

cv2.imshow('scaled_image.jpg', scaled_image)
cv2.imshow('gamma_corrected_image.jpg', gamma_corrected_image)
cv2.imshow('clipped_image.jpg', clipped_image)
cv2.imshow('windowed_image.jpg', windowed_image)
